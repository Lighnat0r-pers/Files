Run the Master EXE if you want to read the values from the game directly.
Run the Slave EXE if you want to read the values from someone else's PC. Make sure you enter the same team name as the person with the Master EXE you want the values from.
