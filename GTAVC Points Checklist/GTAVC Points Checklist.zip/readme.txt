Run the Master EXE if you want to read the values from the game directly.
Run the Slave EXE if you want to read the values from someone else's PC.
