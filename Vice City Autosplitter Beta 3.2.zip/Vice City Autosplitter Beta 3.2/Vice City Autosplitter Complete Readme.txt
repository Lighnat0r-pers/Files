Vice City Autosplitter

Closing the game and restarting it will cause the autosplitter to stop working.

Beta 3.2 Updates:
Bugfix: The timer is no longer started 500 ms late (sorry!).





General Information:

This program will eliminate the margin of error caused by manual splitting for any% speedruns. 
Start the program before running Vice City. It will send key presses to a split program of your choosing, such as WSplit or Llanfair.
The accuracy of the program is 17ms on average, varying between 10 and 50ms. (As a reference, one frame is 33ms long)




Compatibility:

The script is compatible with Vice City 1.0, Vice City 1.1 and the Steam version of Vice City.
It will automatically detect which version is running.


Known Limitations:

The script will not show the full file name of setting files over approximately 150 characters.
It is not possible to set the split hotkeys while some split programs are running. (WSplit doesn't work, LLanfair does)
Overwriting an already existing file when saving the splits doesn't work as expected (it will instead create a new file with .ini added to the file name).
If you delete a file in the file selection, the script still thinks the file exists.
If you load a settings file which does not contain the right information and select immediate start, the script will not work (although it doesn't give an error, because it doesn't check this yet).
Using commas in the save settings file name makes the script unable to load it.


Created by Lighnat0r
Contact me at Lighnat0r@gmail.com for any questions, bugs, suggestions or find me in the speedrunslive.com #gta irc channel.




Credits to Justshanzz and eidgod for testing the beta versions of the script and identifying a number of bugs as well as offering thoughts on features.
Credits to geekdude for the custom memory function






Future Changes/Ideas/Things to add:

Make it more clear that the program sends splits to a timer program such as WSplit or Llanfair. It doesn't keep track of the time itself (add this in a later version?).

Add sub-mission goals (i.e. getting the phone in BAB, stuff like that)

Maybe add split options for when all things of one section are done (e.g. all safehouses owned)

Add an extra goal: other, which has all split possibilities unlocked (i.e. same as 100%).

Splits for a certain number (of own choosing, just like the Cone Crazy laps thingy) of collectables (and taxi fares, maybe at a level of own choosing in e.g. Paramedic/Pizza as well) gathered, instead just being able to split at all collected. An example could also be splitting at every cone crazy lap instead of just the last one.  Maybe by creating 1 main control, containing how many splits for that thing and then others, equal to the amount specified which would allow choosing where they split. Would require updating that section every time the main control is changed (which is possible, see command list somewhere). Also would need to add that, if applicable, if you fail the mission after getting a split but before being done, the split is un-split and the script restarts looking for that objective.

Adding goals: for each 100% segment. Add 100% segmented in the main list, upon selecting that create a new dropdown menu containing the segments to be able to keep overview in the main list instead of flooding it.

For the goal selection window add a help button/text explaining what each goal encompasses. Perhaps a textbox underneath the DDL which changes due to a g-label in the DDL. It would contain a brief description and where applicable a hyperlink to a more detailed description/list of included missions.

Maybe add a previous button if viable.

Updating where you want to split/goal on the fly, especially for segmented 100% (maybe add a definable hotkey which allows changing to the next/previous segment, with a tooltip thingy showing what segment is active/activated.

Select/Deselect button is still slow for some goals. Change it so it is quicker.

Add an option to make the timer pause if in the game menu.

When loading an ini file and selecting immediate start the script doesn't actually check if the file contains the right info. Add a checksum of sorts.

Status bar showing on which step out of the total you are.

Make autoresizing more flexible or at least fix it so it works with the non linear groupboxes.

The while errorlevel != 0 lines are pretty useless since the errorlevel is never updated. Only thing it�s good for is that it works as a loop. Can be replaced by e.g. if errorlevel != 0 then loop or by adding something in the while that updates the errorlevel.

Maybe change where the autoresizing happens to just before the groupbox is created by checking the y+height of the previous groupbox. This is probably more suitable for automating the creation process.

Find a way to check if the loaded save is from the same game to avoid screwups with the autosplitter.

When opening a settings file but not changing anything, skip the save window.

When the select splits window is resized the OK, Cancel and Restart Program buttons are only found on the last tab. When you're on the first page and you don't see the buttons, it might be unclear how to procede.

Find the memory address(es) to be able to split on saving.

Once the split names are fully separated, put them in a separate file and use #Include. This would also allow easy switching between games.

Add welcome screen in the program which explains how it works.

In the splits loop, add requirement. Basically if the requirement isn't done, there is no possibility that the split itself is done so there's no need to check. (for example, all hands on deck when sir yes sir is not done yet)

In the splits loop, add header. Basically header is the name of the groupbox, if the header is the same as currentgroupbox variable (add this as well upon creation of the groupbox) just add it, otherwise create a new groupbox named %header%. Not sure how this is compatible with the size of the groupboxes, either change it every time you add a new checkbox, or calculate all of them beforehand.



Old Update Notes:

Beta 3.1 Updates:
Kill trigger hotkey removed.
Added compatibility for the following hotkeys: Space, Backspace, Tab, LWin, RWin, Delete, Enter, NumpadDelete, NumpadEnter, LCtrl, RCtrl, LShift, RShift, LAlt, RAlt, Printscreen, AppsKey, Middle mouse button, Extra mouse button 1, Extra mouse button 2, Mousewheel scroll down, Mousewheel scroll up, Mousewheel scroll left, Mousewheel scroll right. Some of these hotkeys don't properly show their name in the box, but they do work.
Fixed a bug causing the wrong text to appear in the select splits window for Cone Crazy when Mission% was selected as goal.

Beta 3 Hotfix Updates:
The autosplitter now shuts itself down when the game is closed/crashes when pause on close is not active.
Some efficiency improvements.
Fixed an issue which caused the splits to not restart after reloading a save.
Removed Dirtring%

Beta 3 Updates:
The autosplitter will now optionally work correctly even if the game crashes or you load a save. You can enable both options in the hotkeys menu. Crashing (or closing the game) will cause the timer to be paused. After a crash you can either load a save which will unpause the timer or start a new game, which will reset the timer as usual (Closing/crashing again will keep the timer paused). When loading a save the autosplitter will check all the splits if they are still completed, if they are not it will automatically unsplit them.
Added the open recent option.
The autosplitter is now compatible with smaller resolutions and will automatically resize if required.

New icon design. Still not the most amazing thing in the world, but at least it is now distinguishable.
Hotkeys are now stored in a separate file since they're most likely to be the same for every run setting anyway. Settings for loading saves and game crashes are also stored in this file.
Changed the way the program determines the version of Vice City. It is now both faster and more reliable.
Rewrote some hotkey code to make it work more efficiently with the growing number of hotkeys.

Fixed a bug where Cone Crazy would always split on the first lap if the split was turned off.
Multiple bug fixes in the select file window.
Changed the description of the Cone Crazy split to clarify that it only splits after the last lap. 
Fixed some stuff with the KYFC split. I hope this fixed the issues, but I'm not sure.


Beta 2.1 Updates:
Fixed the splits for owning the assets so they actually work.
Fixed the script so it can also be used without setting a kill trigger instead of giving an error.



Beta 2 Updates:
Added splits for owning the assets.
Added restart button in the gui windows.
The any% final split is now at losing control of Tommy at the end of Keep Your Friends Close as it should be, instead of at the mission passed text.

Added traytip telling that the script is running in the background.
Designed a (basic) custom tray menu.
Added 100% split to use as the 100% final split.
Added an optional kill trigger (hotkey to immediately close the program)

Some improvements/fixes related to exiting the script.
Select hotkeys and choose goal windows now consolidated into one window.
The select/deselect all checkbox is much more efficient now due to a change in the way the script handles the first and the final splits. However, for some of the goals it isn't any faster.
Improved efficiency in the requirements list (for 100% and Dirtring%).
Improved efficiency in the Select Splits window.
