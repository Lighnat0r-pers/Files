Welcome to the OHKO Mod! This mod will cause all kinds of effects to trigger while playing GTA: San Andreas. As it does not change any game files, you do not have to worry about messing up the game.

Instructions:
Just run the executable together with the game, everything needed will be changed automatically (as well as restored when you close the OHKO.exe)

Created by Lighnat0r
Contact me at Lighnat0r@gmail.com for any questions, bugs, suggestions or find me in the speedrunslive.com #gta irc channel. You can also message me on Twitch (www.twitch.tv/Lighnat0r)
