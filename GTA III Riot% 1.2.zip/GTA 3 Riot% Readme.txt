Welcome to Riot%! This mod will cause all kinds of madess while playing GTA III. As it does not change any game files, you do not have to worry about messing up the game.

Instructions:
Just run the executable together with the game, everything needed will be changed automatically (as well as restored when you close the riot%.exe)
When ingame, you can press F5 when not in a vehicle or on a mission to open the save menu. 




Detailed Effects:
All peds carry weapons.
All peds are hostile towards everyone (including the player).
Much more random traffic will spawn.
Top-Down and Cinematic camera modes are disabled so despawning traffic this way is not possible.
In The Exchange, Maria and the cartel gang member attack eachother, which
without intervention results in Maria's death and mission fail, so Maria is
made immune to all non-player damage.

There are certain moments in the game such as immediately after loading a save where using Quicksave could cause issues, such as softlocking the game or creating a corrupted save. Please use common sense, it's not hard to avoid this.

Created by Lighnat0r, idea by ComradeMajor
Contact me at Lighnat0r@gmail.com for any questions, bugs, suggestions or find me in the speedrunslive.com #gta irc channel. You can also message me on Twitch (www.twitch.tv/Lighnat0r)
